export class Customers {
   customerEmail: string;
   customerPassword: string;
   customerName: string;
   customerMobile: string;
   customerAddress: string;
   customerPincode: string;
}
